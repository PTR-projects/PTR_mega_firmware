#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "driver/adc.h"
#include "esp_adc_cal.h"
#include "AnalogMeas.h"

#define GET_UNIT(x)        ((x>>3) & 0x1)

esp_adc_cal_characteristics_t  * adc_chars;


void Analog_init(){
    //Check if TP is burned into eFuse
    if (esp_adc_cal_check_efuse(ESP_ADC_CAL_VAL_EFUSE_TP) == ESP_OK) {
        printf("eFuse Two Point: Supported\n");
    } else {
        printf("eFuse Two Point: NOT supported\n");
    }
    //Check Vref is burned into eFuse
    if (esp_adc_cal_check_efuse(ESP_ADC_CAL_VAL_EFUSE_VREF) == ESP_OK) {
        printf("eFuse Vref: Supported\n");
    } else {
        printf("eFuse Vref: NOT supported\n");
    }

    adc1_config_width(ADC_WIDTH_BIT_10);
    adc1_config_channel_atten(ADC1_CHANNEL_0, ADC_ATTEN_DB_11); //PAR1
    adc1_config_channel_atten(ADC1_CHANNEL_1, ADC_ATTEN_DB_11); //PAR2
    adc1_config_channel_atten(ADC1_CHANNEL_6, ADC_ATTEN_DB_11); //BAT

    //Characterize ADC
    adc_chars = calloc(1, sizeof(esp_adc_cal_characteristics_t));
    esp_adc_cal_value_t val_type = esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_DB_11, ADC_WIDTH_BIT_10, 1100, adc_chars);
    //print_char_val_type(val_type);
}

//void Analog_init(){
//    #define ADC_RESULT_BYTE     2
//    #define ADC_CONV_LIMIT_EN   1                       //For ESP32, this should always be set to 1
//    #define ADC_CONV_MODE       ADC_CONV_SINGLE_UNIT_1  //ESP32 only supports ADC1 DMA mode
//    #define ADC_OUTPUT_TYPE     ADC_DIGI_OUTPUT_FORMAT_TYPE1
//
//    static uint16_t adc1_chan_mask = BIT(0) | BIT(1) | BIT(6);	// 0-PAR2, 1-PAR1, 6-VBAT
//    static uint16_t adc2_chan_mask = 0;
//    static adc_channel_t channel[3] = {ADC1_CHANNEL_0, ADC1_CHANNEL_1, ADC1_CHANNEL_6};
//
//    adc_digi_init_config_t adc_dma_config = {
//        .max_store_buf_size = 1024,
//        .conv_num_each_intr = 256,
//        .adc1_chan_mask = adc1_chan_mask,
//        .adc2_chan_mask = adc2_chan_mask,
//    };
//    ESP_ERROR_CHECK(adc_digi_initialize(&adc_dma_config));
//
//    adc_digi_configuration_t dig_cfg = {
//        .conv_limit_en = ADC_CONV_LIMIT_EN,
//        .conv_limit_num = 250,
//        .sample_freq_hz = 750 ,
//        .conv_mode = ADC_CONV_MODE,
//        .format = ADC_OUTPUT_TYPE,
//    };
//
//    adc_digi_pattern_config_t adc_pattern[SOC_ADC_PATT_LEN_MAX] = {0};
//    dig_cfg.pattern_num = 3;
//    for (int i = 0; i < 3; i++) {
//        uint8_t unit = GET_UNIT(channel[i]);
//        uint8_t ch = channel[i] & 0x7;
//        adc_pattern[i].atten = ADC_ATTEN_DB_11;
//        adc_pattern[i].channel = ch;
//        adc_pattern[i].unit = unit;
//        adc_pattern[i].bit_width = 1;
//
//        //ESP_LOGI(TAG, "adc_pattern[%d].atten is :%x", i, adc_pattern[i].atten);
//        //ESP_LOGI(TAG, "adc_pattern[%d].channel is :%x", i, adc_pattern[i].channel);
//        //ESP_LOGI(TAG, "adc_pattern[%d].unit is :%x", i, adc_pattern[i].unit);
//    }
//    dig_cfg.adc_pattern = adc_pattern;
//    adc_digi_controller_configure(&dig_cfg);
//    //ESP_ERROR_CHECK(adc_digi_controller_configure(&dig_cfg));
//
//    adc_digi_start();
//}

uint32_t Analog_getPar1(){
    uint32_t adc_reading = adc1_get_raw((adc1_channel_t)ADC1_CHANNEL_0);
    uint32_t voltage = esp_adc_cal_raw_to_voltage(adc_reading, adc_chars);
    //printf("Raw: %d\tVoltage: %dmV\n", adc_reading, voltage);

    return voltage;
}

uint32_t Analog_getPar2(){
    uint32_t adc_reading = adc1_get_raw((adc1_channel_t)ADC1_CHANNEL_1);
    uint32_t voltage = esp_adc_cal_raw_to_voltage(adc_reading, adc_chars);
    //printf("Raw: %d\tVoltage: %dmV\n", adc_reading, voltage);

    return voltage;
}

uint32_t Analog_getVbat(){
    uint32_t adc_reading = adc1_get_raw((adc1_channel_t)ADC1_CHANNEL_6);
    uint32_t voltage = esp_adc_cal_raw_to_voltage(adc_reading, adc_chars);
    //printf("Raw: %d\tVoltage: %dmV\n", adc_reading, voltage);

    return voltage;
}


