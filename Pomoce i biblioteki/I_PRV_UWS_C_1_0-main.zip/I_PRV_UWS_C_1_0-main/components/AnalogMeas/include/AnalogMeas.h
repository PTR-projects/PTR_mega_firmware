void Analog_init();
uint32_t Analog_getPar1();
uint32_t Analog_getPar2();
uint32_t Analog_getVbat();
