#include <stdio.h>
#include <driver/i2c.h>
#include "esp_err.h"
#include "FXOS8700.h"
//https://www.nxp.com/docs/en/data-sheet/FXOS8700CQ.pdf

#define FXOS8700_ADDRESS 0x1E

esp_err_t FXOS8700_register_read(uint8_t reg, uint8_t * data, uint16_t len);
esp_err_t FXOS8700_register_writeByte(uint8_t reg, uint8_t data);

void FXOS8700_init(void)
{
	FXOS8700_register_writeByte(FXOS8700_REG_CTRLREG1, 0x00); // Standby - Reset
	FXOS8700_register_writeByte(FXOS8700_REG_XYZ_DATA_CFG, 0x02); // 8g
	FXOS8700_register_writeByte(FXOS8700_REG_CTRLREG2, 0x00); // mo�na ustawi� HighRes mode <- przetestowa� p�niej
	FXOS8700_register_writeByte(FXOS8700_REG_M_CTRLREG1, 0x1F);	//Hybrid mode (Acc ON, Mag ON)
	FXOS8700_register_writeByte(FXOS8700_REG_M_CTRLREG2, FXOS8700_M_CTRLREG2_AUTOINC_MASK);	// Auto Inc addres - read Acc&Mag in one read

	FXOS8700_register_writeByte(FXOS8700_REG_CTRLREG1,     FXOS8700_CTRLREG1_DR_RATE_200 | FXOS8700_CTRLREG1_ACTIVE_MASK); // 100Hz (1/2 in hybrid mode), Active mode
}

void FXOS8700_readMeas(FXOS8700_t * data){
	//--------------- ACC ------------------------------------
    uint8_t buf[14] = {0};
    FXOS8700_register_read(0x00, buf, 13);

    uint8_t status = buf[0];
    data->accX_raw = ((int16_t)(buf[1]<<8 | buf[2]) >> 2) * 0.000976f;
    data->accY_raw = ((int16_t)(buf[3]<<8 | buf[4]) >> 2) * 0.000976f;
    data->accZ_raw = ((int16_t)(buf[5]<<8 | buf[6]) >> 2) * 0.000976f;

    data->accX = 0.95f * data->accX + 0.05f * data->accX_raw;
    data->accY = 0.95f * data->accY + 0.05f * data->accY_raw;
    data->accZ = 0.95f * data->accZ + 0.05f * data->accZ_raw;


    data->magX_raw = ((int16_t)(buf[7] <<8 | buf[8] )) * 0.1f - 6.0f;
	data->magY_raw = ((int16_t)(buf[9] <<8 | buf[10])) * 0.1f + 25.0f;
	data->magZ_raw = ((int16_t)(buf[11]<<8 | buf[12])) * 0.1f - 95.0f;

	data->magX = 0.95f * data->magX + 0.05f * data->magX_raw;
	data->magY = 0.95f * data->magY + 0.05f * data->magY_raw;
	data->magZ = 0.95f * data->magZ + 0.05f * data->magZ_raw;
}

uint8_t FXOS8700_WhoAmI(){
	uint8_t data[2];
	if(FXOS8700_register_read(0x0D, data, 1))
		return -1;

	return data[0];
}

//-------------- Low Level I2C HAL ----------------------------------------
esp_err_t FXOS8700_register_read(uint8_t reg, uint8_t * data, uint16_t len){
	return i2c_master_write_read_device(0, FXOS8700_ADDRESS, &reg, 1, data, len, 2);
}

esp_err_t FXOS8700_register_writeByte(uint8_t reg, uint8_t data){
	int ret;
	uint8_t write_buf[2] = {reg, data};

	ret = i2c_master_write_to_device(0, FXOS8700_ADDRESS, write_buf, sizeof(write_buf), 2);

	return ret;
}
