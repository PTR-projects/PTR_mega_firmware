#include <stdio.h>
#include <driver/i2c.h>
#include "esp_err.h"
#include "I2C_DRIVER.h"

#define _I2C_NUMBER(num) I2C_NUM_##num
#define I2C_NUMBER(num) _I2C_NUMBER(num)
#define I2C_MASTER_SCL_IO 22                                  /*!< gpio number for I2C master clock */
#define I2C_MASTER_SDA_IO 19                                  /*!< gpio number for I2C master data  */
#define I2C_MASTER_FREQ_HZ 100000                             /*!< I2C master clock frequency */

esp_err_t I2C_init(void)
{
	int i2c_master_port = I2C_NUMBER(0);
	i2c_config_t conf = {
		.mode = I2C_MODE_MASTER,
		.sda_io_num = I2C_MASTER_SDA_IO,
		.scl_io_num = I2C_MASTER_SCL_IO,
		.sda_pullup_en = GPIO_PULLUP_ENABLE,
		.scl_pullup_en = GPIO_PULLUP_ENABLE,
		.master.clk_speed = I2C_MASTER_FREQ_HZ
	};

	esp_err_t err = i2c_param_config(i2c_master_port, &conf);
	if (err != ESP_OK) {
		return err;
	}

	return i2c_driver_install(i2c_master_port, conf.mode, 0, 0, 0);
}
