
typedef enum{
	NOIGN_NOARM,
	IGN_NOARM,
	NOIGN_ARM,
	IGN_ARM
} IGN_cont;

void IGN_srv();
IGN_cont IGN_getPar_cont(uint32_t val);
