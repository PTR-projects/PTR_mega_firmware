#include <stdio.h>
#include "AnalogMeas.h"
#include "LED.h"
#include "IGN.h"

uint32_t par1_cont_raw = 0;
uint32_t par2_cont_raw = 0;

IGN_cont par1_cont = NOIGN_NOARM;
IGN_cont par2_cont = NOIGN_NOARM;

void IGN_srv(){
	par1_cont_raw = Analog_getPar1();
	par2_cont_raw = Analog_getPar2();

    // Res > 1300 mV = no Ign, no Arm
    // Res 1000-1300mV = Ign, no Arm
    // Res 580-760 = no Ign, Arm
    // Res <200 = Ign, Arm

	if(par1_cont != IGN_getPar_cont(par1_cont_raw)){
		par1_cont = IGN_getPar_cont(par1_cont_raw);
		if(par1_cont == NOIGN_NOARM) 	LED_setPar1(0);
		if(par1_cont == NOIGN_ARM) 		LED_setPar1(0);
		if(par1_cont == IGN_NOARM) 		LED_setPar1(50);
		if(par1_cont == IGN_ARM) 		LED_setPar1(100);
	}

	if(par2_cont != IGN_getPar_cont(par2_cont_raw)){
		par2_cont = IGN_getPar_cont(par2_cont_raw);
		if(par2_cont == NOIGN_NOARM) 	LED_setPar2(0);
		if(par2_cont == NOIGN_ARM) 		LED_setPar2(0);
		if(par2_cont == IGN_NOARM) 		LED_setPar2(50);
		if(par2_cont == IGN_ARM) 		LED_setPar2(100);
	}


    //printf("Par1: %dmv\tPar2: %dmV\n", par1_cont, par2_cont);
}

IGN_cont IGN_getPar_cont(uint32_t val){
	if(val > 1300)
		return NOIGN_NOARM;

	else if(val > 900)
		return IGN_NOARM;

	else if(val > 500)
		return NOIGN_ARM;

	else
		return IGN_ARM;
}

