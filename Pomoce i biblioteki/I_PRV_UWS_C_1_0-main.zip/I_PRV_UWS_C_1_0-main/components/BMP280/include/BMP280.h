typedef struct{
	uint32_t press_raw;
	uint32_t temp_raw;
	float press;
	float temp;
} BMP280_t;

typedef struct{
	uint16_t T1;
	int16_t  T2;
	int16_t  T3;
	uint16_t P1;
	int16_t  P2;
	int16_t  P3;
	int16_t  P4;
	int16_t  P5;
	int16_t  P6;
	int16_t  P7;
	int16_t  P8;
	int16_t  P9;
} BMP280_cal_t;

void BMP280_init(void);
void BMP280_readMeas(BMP280_t * data);
uint8_t BMP280_WhoAmI();


/**
 * BMP280 registers
 */
#define BMP280_REG_TEMP_XLSB   0xFC /* bits: 7-4 */
#define BMP280_REG_TEMP_LSB    0xFB
#define BMP280_REG_TEMP_MSB    0xFA
#define BMP280_REG_TEMP        (BMP280_REG_TEMP_MSB)
#define BMP280_REG_PRESS_XLSB  0xF9 /* bits: 7-4 */
#define BMP280_REG_PRESS_LSB   0xF8
#define BMP280_REG_PRESS_MSB   0xF7
#define BMP280_REG_PRESSURE    (BMP280_REG_PRESS_MSB)
#define BMP280_REG_CONFIG      0xF5 /* bits: 7-5 t_sb; 4-2 filter; 0 spi3w_en */
#define BMP280_REG_CTRL        0xF4 /* bits: 7-5 osrs_t; 4-2 osrs_p; 1-0 mode */
#define BMP280_REG_STATUS      0xF3 /* bits: 3 measuring; 0 im_update */
#define BMP280_REG_CTRL_HUM    0xF2 /* bits: 2-0 osrs_h; */
#define BMP280_REG_RESET       0xE0
#define BMP280_REG_ID          0xD0
#define BMP280_REG_CALIB       0x88
#define BMP280_REG_HUM_CALIB   0x88

#define BMP280_RESET_VALUE     0xB6

#define BMP280_MODE_SLEEP  0 //!< Sleep mode
#define BMP280_MODE_FORCED 1 //!< Measurement is initiated by user
#define BMP280_MODE_NORMAL 3 //!< Continues measurement

#define BMP280_FILTER_OFF  (0 << 2)
#define BMP280_FILTER_2    (1 << 2)
#define BMP280_FILTER_4    (2 << 2)
#define BMP280_FILTER_8    (3 << 2)
#define BMP280_FILTER_16   (4 << 2)

/**
 * Pressure oversampling settings
 */
#define BMP280_P_SKIPPED  		 (0 << 2)  //!< no measurement
#define BMP280_P_ULTRA_LOW_POWER (1 << 2)  //!< oversampling x1
#define BMP280_P_LOW_POWER  	 (2 << 2)  //!< oversampling x2
#define BMP280_P_STANDARD  		 (3 << 2)  //!< oversampling x4
#define BMP280_P_HIGH_RES  		 (4 << 2)  //!< oversampling x8
#define BMP280_P_ULTRA_HIGH_RES  (5 << 2)  //!< oversampling x16;

/**
 * Temperature oversampling settings
 */
#define BMP280_T_SKIPPED  		 (0 << 5)  //!< no measurement
#define BMP280_T_ULTRA_LOW_POWER (1 << 5)  //!< oversampling x1
#define BMP280_T_LOW_POWER  	 (2 << 5)  //!< oversampling x2
#define BMP280_T_STANDARD  		 (3 << 5)  //!< oversampling x4
#define BMP280_T_HIGH_RES  		 (4 << 5)  //!< oversampling x8
#define BMP280_T_ULTRA_HIGH_RES  (5 << 5)  //!< oversampling x16;

/**
 * Stand by time between measurements in normal mode
 */
#define BMP280_STANDBY_05    (0 << 5)   //!< stand by time 0.5ms
#define BMP280_STANDBY_62    (1 << 5)   //!< stand by time 62.5ms
#define BMP280_STANDBY_125   (2 << 5)   //!< stand by time 125ms
#define BMP280_STANDBY_250   (3 << 5)   //!< stand by time 250ms
#define BMP280_STANDBY_500   (4 << 5)   //!< stand by time 500ms
#define BMP280_STANDBY_1000  (5 << 5)   //!< stand by time 1s
#define BMP280_STANDBY_2000  (6 << 5)   //!< stand by time 2s BMP280, 10ms BME280
#define BMP280_STANDBY_4000  (7 << 5)   //!< stand by time 4s BMP280, 20ms BME280

