#include <stdio.h>
#include <driver/i2c.h>
#include "esp_err.h"
#include "BMP280.h"
// https://cdn-shop.adafruit.com/datasheets/BST-BMP280-DS001-11.pdf
// https://github.com/UncleRus/esp-idf-lib/blob/master/components/bmp280/bmp280.c

#define ADXL345_ADDRESS 0x76

BMP280_cal_t BMP280_cal_d;

esp_err_t BMP280_register_read(uint8_t reg, uint8_t * data, uint16_t len);
esp_err_t BMP280_register_writeByte(uint8_t reg, uint8_t data);
esp_err_t BMP280_readCalibration();

void BMP280_init(void)
{
	BMP280_readCalibration();
	BMP280_register_writeByte(BMP280_REG_CONFIG, BMP280_STANDBY_05 | BMP280_FILTER_4);	// min stanby time, IIR filter set to 4 (test needed)
	BMP280_register_writeByte(BMP280_REG_CTRL,   BMP280_T_ULTRA_LOW_POWER | BMP280_P_LOW_POWER | BMP280_MODE_NORMAL);	// Temp oversampling x1, Pressure x2, Continues mode
}

esp_err_t BMP280_readCalibration()
{
	uint8_t buf[25] = {0};
	BMP280_register_read(0x88, buf, 24);

	BMP280_cal_d.T1 = *((uint16_t*)&buf[0]);
	BMP280_cal_d.T2 = *((uint16_t*)&buf[2]);
	BMP280_cal_d.T3 = *((uint16_t*)&buf[4]);
	BMP280_cal_d.P1 = *((uint16_t*)&buf[6]);
	BMP280_cal_d.P2 = *((uint16_t*)&buf[8]);
	BMP280_cal_d.P3 = *((uint16_t*)&buf[10]);
	BMP280_cal_d.P4 = *((uint16_t*)&buf[12]);
	BMP280_cal_d.P5 = *((uint16_t*)&buf[14]);
	BMP280_cal_d.P6 = *((uint16_t*)&buf[16]);
	BMP280_cal_d.P7 = *((uint16_t*)&buf[18]);
	BMP280_cal_d.P8 = *((uint16_t*)&buf[20]);
	BMP280_cal_d.P9 = *((uint16_t*)&buf[22]);

   return ESP_OK;
}

void BMP280_readMeas(BMP280_t * data){
    uint8_t buf[7] = {0};
    BMP280_register_read(0xF7, buf, 6);

    data->press_raw = ((int32_t)(((int32_t)buf[0])<<16 | ((int32_t)buf[1])<<8 | (int32_t)buf[2])) >> 4;
    data->temp_raw  = ((int32_t)(buf[3]<<16 | buf[4]<<8 | buf[5])) >> 4;

    //--------- Temp -------------
    double var1  = ((((data->temp_raw >> 3) - ((int32_t)BMP280_cal_d.T1 << 1))) * ((int32_t)BMP280_cal_d.T2)) >> 11;
    double var2  = (((((data->temp_raw >> 4) - ((int32_t)BMP280_cal_d.T1)) * ((data->temp_raw >> 4) - ((int32_t)BMP280_cal_d.T1))) >> 12) * ((int32_t)BMP280_cal_d.T3)) >> 14;

    data->temp = (var1 + var2) / 5120.0;


    //--------- Press -----------
    double var3, var4, p;

    var3 = (double)(var1 + var2)/2.0 - 64000.0;
    var4 = var3 * var3 * (double)BMP280_cal_d.P6 / 32768.0;
    var4 = var4 + ((var3 * (double)BMP280_cal_d.P5) * 2.0);
    var4 = (var4/4.0) + (((double)BMP280_cal_d.P4) * 65536.0);
	var3 = (((var3 * var3 * (double)BMP280_cal_d.P3) / 524288.0) + ((var3 * (double)BMP280_cal_d.P2))) / 524288.0;
	var3 = (1.0 + var3/32768.0)*((double)BMP280_cal_d.P1);

	if (var3 == 0) return;  // avoid exception caused by division by zero

	p = 1048576.0 - (double)(data->press_raw);
	p = (p - (var4 / 4096.0))*6250.0 / var3;
	var3 = ((double)BMP280_cal_d.P9) * p*p / 2147483648.0;
	var4 = p*((double)BMP280_cal_d.P8) / 32768.0;
	p = p + (var3 + var4 + ((double)BMP280_cal_d.P7)) / 16.0;

	data->press = p;
}

uint8_t BMP280_WhoAmI(){
	uint8_t data[2];
	if(BMP280_register_read(0xD0, data, 1))
		return -1;

	return data[0];
}


//-------------- Low Level I2C HAL ----------------------------------------
esp_err_t BMP280_register_read(uint8_t reg, uint8_t * data, uint16_t len){
	return i2c_master_write_read_device(0, 0x76, &reg, 1, data, len, 2);
}

esp_err_t BMP280_register_writeByte(uint8_t reg, uint8_t data){
	int ret;
	uint8_t write_buf[2] = {reg, data};

	ret = i2c_master_write_to_device(0, 0x76, write_buf, sizeof(write_buf), 2);

	return ret;
}
