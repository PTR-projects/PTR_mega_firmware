typedef enum{
	UWS_NO_TRIGGER,
	UWS_TRIGGERED_LOW,
	UWS_TRIGGERED_MID,
	UWS_TRIGGERED_HIGH
} UWS_state_t;


void UWS_init(void);
void UWS_srv(FXOS8700_t * data);
UWS_state_t UWS_getState();
