#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "FXOS8700.h"
#include "UWS.h"

UWS_state_t UWS_state_d = UWS_NO_TRIGGER;


void UWS_init(void)
{

}

void UWS_srv(FXOS8700_t * data){

	float magX = data->magX;
	float magY = data->magY;
	float magZ = data->magZ;

	float magXZ = sqrtf(magX*magX + magZ*magZ);
	if(magXZ == 0.0f) return;

	float tang = magY / magXZ;

	if(tang <  0.6f)
		UWS_state_d = UWS_TRIGGERED_LOW;
	if(tang <  0.0f)
		UWS_state_d = UWS_TRIGGERED_MID;
	if(tang < -0.6f)
		UWS_state_d = UWS_TRIGGERED_HIGH;
	if(tang >  0.6f)
		UWS_state_d = UWS_NO_TRIGGER;


}

UWS_state_t UWS_getState(){
	return UWS_state_d;
}
