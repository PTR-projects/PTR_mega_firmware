void LED_init();

void LED_setRed(uint8_t percentage);
void LED_setGreen(uint8_t percentage);
//void LED_setBat(uint8_t percentage);
void LED_setPar1(uint8_t percentage);
void LED_setPar2(uint8_t percentage);
void LED_setBatBlinker(uint8_t blinks);

#define GPIO_LED_STAT_BAT       21
#define GPIO_LED_IGN_1          9
#define GPIO_LED_IGN_2          20
#define GPIO_LED_RED          	10
#define GPIO_LED_GREEN          7
