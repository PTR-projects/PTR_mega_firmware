#include <stdio.h>
#include "driver/ledc.h"
#include "driver/rmt.h"
#include "LED.h"

void rmt_tx_init(void);

static rmt_item32_t morse_esp[] = {
    {{{ 300,  1, 2700, 0 }}},
    {{{ 1500, 1, 1500, 0 }}},
    {{{ 1500, 1, 1500, 0 }}},
    {{{ 1500, 1, 1500, 0 }}},
	{{{ 1500, 1, 1500, 0 }}},
	{{{ 1500, 1, 1500, 0 }}},
    {{{ 0, 0, 0, 0 }}}
};

void LED_init(){
    // Prepare and then apply the LEDC PWM timer configuration
    ledc_timer_config_t ledc_timer = {
        .speed_mode       = LEDC_LOW_SPEED_MODE,
        .timer_num        = LEDC_TIMER_0,
        .duty_resolution  = LEDC_TIMER_8_BIT,
        .freq_hz          = 4,  // Set output frequency at 5 kHz
        .clk_cfg          = LEDC_AUTO_CLK
    };
    ESP_ERROR_CHECK(ledc_timer_config(&ledc_timer));

    // Prepare and then apply the LEDC PWM channel configuration
    ledc_channel_config_t ledc_channel = {
        .speed_mode     = LEDC_LOW_SPEED_MODE,
        .channel        = LEDC_CHANNEL_0,
        .timer_sel      = LEDC_TIMER_0,
        .intr_type      = LEDC_INTR_DISABLE,
        .gpio_num       = 7,
        .duty           = 0, // Set duty to 0%
        .hpoint         = 0
    };

    //Red
    ledc_channel.channel = LEDC_CHANNEL_0;
    ledc_channel.gpio_num       = GPIO_LED_RED,
    ledc_channel_config(&ledc_channel);

    //Green
	ledc_channel.channel = LEDC_CHANNEL_1;
	ledc_channel.gpio_num       = GPIO_LED_GREEN,
	ledc_channel_config(&ledc_channel);

//	//Bat
//	ledc_channel.channel = LEDC_CHANNEL_2;
//	ledc_channel.gpio_num       = 21,
//	ledc_channel_config(&ledc_channel);

    //Par1
    ledc_channel.channel = LEDC_CHANNEL_3;
    ledc_channel.gpio_num       = GPIO_LED_IGN_2,
    ledc_channel_config(&ledc_channel);

    //Par2
    ledc_channel.channel = LEDC_CHANNEL_4;
    ledc_channel.gpio_num       = GPIO_LED_IGN_1,
    ledc_channel_config(&ledc_channel);

    rmt_tx_init();  //BAT level blinker
}

void LED_setRed(uint8_t percentage){
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, (float)percentage * 256.0f / 100.0f);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
}

void LED_setGreen(uint8_t percentage){
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1, (float)percentage * 256.0f / 100.0f);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1);
}

//void LED_setBat(uint8_t percentage){
//    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, (float)percentage * 256.0f / 100.0f);
//    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2);
//}


void LED_setPar1(uint8_t percentage){
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_3, (float)percentage * 256.0f / 100.0f);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_3);
}

void LED_setPar2(uint8_t percentage){
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4, (float)percentage * 256.0f / 100.0f);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4);
}


//----------- Bat LED blinker ---------------------------
void LED_setBatBlinker(uint8_t blinks){
	morse_esp[0].level0 = (blinks == 0);
	morse_esp[1].level0 = (blinks >= 1);
	morse_esp[2].level0 = (blinks >= 2);
	morse_esp[3].level0 = (blinks >= 3);
	morse_esp[4].level0 = (blinks >= 4);
	morse_esp[5].level0 = (blinks >= 5);

	ESP_ERROR_CHECK(rmt_write_items(RMT_CHANNEL_0, morse_esp, sizeof(morse_esp) / sizeof(morse_esp[0]), false));
}

void rmt_tx_init(void) {
    rmt_config_t config = RMT_DEFAULT_CONFIG_TX(GPIO_LED_STAT_BAT, RMT_CHANNEL_0);
    // enable the carrier to be able to hear the Morse sound
    // if the RMT_TX_GPIO is connected to a speaker
    config.tx_config.carrier_en = false;
    // set the maximum clock divider to be able to output
    // RMT pulses in range of about one hundred milliseconds
    config.clk_div = 255;
    config.tx_config.loop_en = false;

    ESP_ERROR_CHECK(rmt_config(&config));
    ESP_ERROR_CHECK(rmt_set_source_clk(RMT_CHANNEL_0, RMT_BASECLK_REF));
    ESP_ERROR_CHECK(rmt_driver_install(config.channel, 0, 0));
}
