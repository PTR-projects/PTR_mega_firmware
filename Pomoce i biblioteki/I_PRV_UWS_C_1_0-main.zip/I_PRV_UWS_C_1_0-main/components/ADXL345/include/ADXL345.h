typedef struct{
    float accX_raw;
    float accY_raw;
    float accZ_raw;
    float accX;
    float accY;
    float accZ;
} ADXL345_t;


void ADXL345_init(void);
void ADXL345_readMeas(ADXL345_t * data);
uint8_t ADXL345_WhoAmI();
