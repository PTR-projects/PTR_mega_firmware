#include <stdio.h>
#include <driver/i2c.h>
#include "esp_err.h"
#include "ADXL345.h"

#define ADXL345_ADDRESS 0x1D

esp_err_t ADXL345_register_read(uint8_t reg, uint8_t * data, uint16_t len);
esp_err_t ADXL345_register_writeByte(uint8_t reg, uint8_t data);

void ADXL345_init(void)
{
	ADXL345_register_writeByte(0x2C, 0x0A); // 9-50Hz, A-100Hz, D-800Hz
	ADXL345_register_writeByte(0x2D, 0x08); // Meas ON
	ADXL345_register_writeByte(0x31, 0x0B); // 16g, full res
}

void ADXL345_readMeas(ADXL345_t * data){
    uint8_t buf[7] = {0};
    ADXL345_register_read(0x32, buf, 6);

    data->accX_raw = (float)((int16_t)(buf[1]<<8 | buf[0])) * 0.0039f;
    data->accY_raw = (float)((int16_t)(buf[3]<<8 | buf[2])) * 0.0039f;
    data->accZ_raw = (float)((int16_t)(buf[5]<<8 | buf[4])) * 0.0039f;

    data->accX = 0.95f * data->accX + 0.05f * data->accX_raw;
    data->accY = 0.95f * data->accY + 0.05f * data->accY_raw;
    data->accZ = 0.95f * data->accZ + 0.05f * data->accZ_raw;
}

uint8_t ADXL345_WhoAmI(){
	uint8_t data[2];
	if(ADXL345_register_read(0x00, data, 1))
		return -1;

	return data[0];
}


//-------------- Low Level I2C HAL ----------------------------------------
esp_err_t ADXL345_register_read(uint8_t reg, uint8_t * data, uint16_t len){
	return i2c_master_write_read_device(0, ADXL345_ADDRESS, &reg, 1, data, len, 2);
}

esp_err_t ADXL345_register_writeByte(uint8_t reg, uint8_t data){
	int ret;
	uint8_t write_buf[2] = {reg, data};

	ret = i2c_master_write_to_device(0, ADXL345_ADDRESS, write_buf, sizeof(write_buf), 2);

	return ret;
}
