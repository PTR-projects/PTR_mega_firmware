#include <stdio.h>
#include <stdlib.h>
#include "AnalogMeas.h"
#include "LED.h"
#include "Battery.h"

uint8_t BAT_Vbat2pulse(uint32_t val_adc_mV);

void BAT_srv(void){
	LED_setBatBlinker(BAT_Vbat2pulse(Analog_getVbat()));
}



uint8_t BAT_Vbat2pulse(uint32_t val_adc_mV){
    uint32_t vbat_mV = val_adc_mV<<1;       //Vbat = ~Vadc * 2
    if(vbat_mV > 4000)  //4.0-4.2
        return 5;
    if(vbat_mV > 3900)  //3.9-4.0
        return 4;
    if(vbat_mV > 3800)  //3.8-3.9
        return 3;
    if(vbat_mV > 3700)  //3.7-3.8
        return 2;
    if(vbat_mV > 3600)  //3.6-3.7
        return 1;
    else                //0.0-3.6
        return 0;
}
