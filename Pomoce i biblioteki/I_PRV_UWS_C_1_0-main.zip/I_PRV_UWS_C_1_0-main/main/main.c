#include "freertos/FreeRTOS.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_event.h"
#include "driver/gpio.h"
#include "LED.h"
#include "IGN.h"
#include "AnalogMeas.h"
#include "I2C_DRIVER.h"
#include "ADXL345.h"
#include "BMP280.h"
#include "FXOS8700.h"
#include "Battery.h"
#include "UWS.h"
#include "WiFi.h"


void vTaskMeas( void * pvParameters )
{
	TickType_t xLastWakeTime;
	const TickType_t xFrequency = 10;	// every 10 ticks = 50*2ms = 50Hz
	BMP280_t 	BMP280_d;
	ADXL345_t 	ADXL345_d;
	FXOS8700_t 	FXOS8700_d;
	uint8_t cnt = 0;


    // Initialise the xLastWakeTime variable with the current time.
    xLastWakeTime = xTaskGetTickCount ();
    for( ;; )
    {
        // Wait for the next cycle.
        xTaskDelayUntil( &xLastWakeTime, xFrequency );

        BMP280_readMeas  (&BMP280_d);
        ADXL345_readMeas (&ADXL345_d);
        FXOS8700_readMeas(&FXOS8700_d);

        UWS_srv(&FXOS8700_d);

        cnt++;
        if(cnt >= 10){
        	cnt = 0;
        	printf("%i\t%.2f;\t%.2f;\t%.2f\n", UWS_getState(), FXOS8700_d.magX, FXOS8700_d.magY, FXOS8700_d.magZ);
        }

    }

    vTaskDelete( NULL );
}

void vTaskStorage( void * pvParameters )
{
	 for( ;; )
	{
		 vTaskDelay(300 / portTICK_PERIOD_MS);
	}

	 vTaskDelete( NULL );
}

void vTaskUtils(void * parameters){
	uint8_t cnt = 30;
	for( ;; ){
		cnt++;
		if(cnt > 30){	//co (0.2s*30) 6s poka� stan baterii
			cnt = 0;
			BAT_srv();
		}
		IGN_srv();		//co (0.2s*1) 200ms sprawd� ci�g�o�� zapalnik�w

		vTaskDelay(200 / portTICK_PERIOD_MS);
	}

	vTaskDelete( NULL );
}

void app_main(void)
{
	//-------- Wifi & storage Init -------------
	nvs_flash_init();
	WiFi_init_softap();

	//-------- Low Level Init ------------------
	LED_init();
	Analog_init();
	I2C_init();
	ADXL345_init();
	BMP280_init();
	FXOS8700_init();

	//-------- Create tasks --------------------
	xTaskCreatePinnedToCore(vTaskMeas,    "Meas task",    2048, NULL, 10, NULL, 0);
	xTaskCreatePinnedToCore(vTaskStorage, "Storage task", 2048, NULL, 10, NULL, 0);
	xTaskCreatePinnedToCore(vTaskUtils,   "Utils task",   2048, NULL, 10, NULL, 1);


	//BMP280_t 	BMP280_d;
	//ADXL345_t 	ADXL345_d;
	//FXOS8700_t 	FXOS8700_d;
	uint8_t cnt = 0;


    while (true) {
    	//BMP280_readMeas  (&BMP280_d);
		//ADXL345_readMeas (&ADXL345_d);
		//FXOS8700_readMeas(&FXOS8700_d);

		//UWS_srv(&FXOS8700_d);

		cnt++;
		if(cnt >= 10){
			cnt = 0;
			//printf("ADXL:%u\tBMP:%u\tFXOS:%u\t\n", ADXL345_WhoAmI(), BMP280_WhoAmI(), FXOS8700_WhoAmI());
		}

        vTaskDelay(20 / portTICK_PERIOD_MS);
    }
}

